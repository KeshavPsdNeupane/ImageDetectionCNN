import csv
import os
from PIL import Image

def csv_to_images_flat(csv_file, output_folder):
    os.makedirs(output_folder, exist_ok=True)

    with open(csv_file, 'r') as f:
        reader = csv.reader(f)
        for idx, row in enumerate(reader):
            label = row[0]
            pixels = list(map(int, row[1:]))
            img = Image.new('L', (28, 28))
            img.putdata(pixels)

            img_name = f"{label}_{idx}.png"
            img.save(os.path.join(output_folder, img_name))

csv_to_images_flat("mnist_train.csv", "mnist_train_images")
csv_to_images_flat("mnist_test.csv", "mnist_test_images")
